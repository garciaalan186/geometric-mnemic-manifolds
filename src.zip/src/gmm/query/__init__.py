"""Query and retrieval module for GMM."""

from .retriever import ManifoldRetriever

__all__ = ['ManifoldRetriever']
