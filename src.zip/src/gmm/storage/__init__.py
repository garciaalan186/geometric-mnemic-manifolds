"""Persistent storage and serialization."""

from .serializer import EngramSerializer

__all__ = ['EngramSerializer']
