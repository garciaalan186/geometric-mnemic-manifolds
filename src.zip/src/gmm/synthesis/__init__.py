"""Synthetic data generation for testing."""

from .biography import SyntheticBiographyGenerator

__all__ = ['SyntheticBiographyGenerator']
