"""Source package for Geometric Mnemic Manifolds."""
